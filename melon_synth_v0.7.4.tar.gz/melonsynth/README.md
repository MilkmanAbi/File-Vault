# Melon Synth

Open singing voice editor. Simple for beginners, powerful for pros.

**Stack:** Electron + React + TypeScript + Python (MLC engine)  
**License:** GPL-3.0 (core), MIT (.mlc addons)

---

## Quick start (Ubuntu / Linux)

```bash
# 1. Prerequisites
sudo apt install python3 python3-pip nodejs npm

# 2. Install JS deps
npm install

# 3. Run in dev mode (starts Vite + Electron together)
npm run dev:electron
```

That's it. The script compiles TypeScript, starts Vite on :5173, waits for it, then launches Electron.

## MLC engine (optional extras)

For full lyric conversion, install Python deps:

```bash
cd mlc
pip3 install -r requirements.txt
# For full G2P (optional, improves accuracy):
sudo apt install espeak-ng
pip3 install phonemizer langdetect nltk
```

Without these, MLC still works using its built-in rule-based engine.

## Dev workflow

```bash
# Terminal 1: watch + recompile Electron TypeScript on change
npm run watch:electron

# Terminal 2: just run Electron (Vite already running)
NODE_ENV=development ./node_modules/.bin/electron .
```

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Vite only (browser) |
| `npm run dev:electron` | Full Electron dev mode |
| `npm run build:all` | Build renderer + Electron |
| `npm run watch:electron` | Watch-compile Electron TS |

## Keyboard shortcuts

| Key | Action |
|---|---|
| ⌘N | New project |
| ⌘O | Open project |
| ⌘S | Save project |
| ⌘I | Import MIDI |
| N | Draw mode |
| S | Select mode |
| E | Erase mode |
| P | Pitch curve mode |
| Space | Play / Pause |
| ⌘Z / ⌘⇧Z | Undo / Redo |
| ⌘A | Select all |
| Delete | Delete selected |
| ⌘K | Command palette |
| ⌘, | Settings |
| ⌘⇧D | Toggle dark mode |

## Project structure

```
melonsynth/
├── src/                    ← React/TypeScript renderer
│   ├── app/components/     ← UI components
│   ├── store/project.ts    ← Zustand state store
│   └── styles/tokens.css   ← Design token system
├── electron-src/           ← Electron main process TypeScript
│   ├── main.ts             ← Window management, IPC routing
│   ├── preload.ts          ← Secure renderer API (window.mlc, window.app)
│   └── voicebank-manager.ts← Voicebank download + install
├── electron/               ← Compiled Electron JS (gitignore in prod)
├── mlc/                    ← Python MLC engine
│   ├── mlc_engine_v2.py    ← IPC server (stdin/stdout JSON)
│   ├── core/               ← G2P, cache, confidence scoring
│   ├── modules/            ← Built-in voicebank mappers
│   ├── addons/             ← Language packs, pipeline plugins
│   └── render/             ← UST generator, render bridge
├── public/
│   └── voicebank-catalog.json ← Community voicebank catalog
└── docs/
    └── WRITING_ADDONS.md   ← How to write .mlc addons
```
