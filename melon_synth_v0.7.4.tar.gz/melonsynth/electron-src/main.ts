/**
 * Melon Synth — Electron Main Process
 * =====================================
 * The supervisor. Has full OS access.
 * Manages: window lifetime, MLC bridge, addon installs,
 *          file dialogs, settings persistence, IPC routing.
 *
 * Architecture:
 *   Renderer (React)  ←→  preload.ts (whitelist)  ←→  main.ts  ←→  Python MLC
 *
 * The MLC Python process is spawned ONCE when the window opens.
 * It lives until the app quits. All conversion/install requests go through it.
 */

import {
  app, BrowserWindow, ipcMain, dialog,
  shell, nativeTheme, protocol, net
} from 'electron';
import { join, resolve }           from 'path';
import { existsSync, mkdirSync,
         readFileSync, writeFileSync,
         copyFileSync }             from 'fs';
import { MLCBridge, registerMLCHandlers } from '../src/engine/mlc-bridge';
import { registerVoicebankHandlers }          from './voicebank-manager';

// ── Paths ─────────────────────────────────────────────────────────────────
// __dirname after compilation = <project>/electron/electron-src/
// PROJECT_ROOT goes up two levels to the repo root.

const isDev    = process.env.NODE_ENV === 'development' || !app.isPackaged;
const PROJECT_ROOT = join(__dirname, '..', '..');   // electron/electron-src → project root
const DIST_DIR = join(PROJECT_ROOT, 'dist');
const PRELOAD  = join(__dirname, 'preload.js');     // same dir as main.js ✓

// User data paths — persisted across sessions, never wiped by browser clears
const USER_DATA   = app.getPath('userData');
const SETTINGS_F  = join(USER_DATA, 'settings.json');
const ADDONS_DIR  = join(USER_DATA, 'addons');
const PROJECTS_DIR  = join(USER_DATA, 'projects');
const VOICEBANKS_DIR = join(USER_DATA, 'voicebanks');

// MLC engine location
// In dev: relative to repo. In production: in extraResources.
const MLC_DIR = app.isPackaged
  ? join(process.resourcesPath, 'mlc')
  : join(PROJECT_ROOT, 'mlc');

// ── Ensure dirs exist ─────────────────────────────────────────────────────

[USER_DATA, ADDONS_DIR, PROJECTS_DIR, VOICEBANKS_DIR].forEach(d => {
  if (!existsSync(d)) mkdirSync(d, { recursive: true });
});

// ── Settings ──────────────────────────────────────────────────────────────

interface UIState {
  windowBounds?:    { x:number; y:number; width:number; height:number };
  voicePanelWidth?: number;
  pitchPanelHeight?: number;
  isDark?:          boolean;
  lastProjectPath?: string;
}

function loadSettings(): UIState {
  try {
    return JSON.parse(readFileSync(SETTINGS_F, 'utf8'));
  } catch {
    return {};
  }
}

function saveSettings(data: Partial<UIState>): void {
  try {
    const current = loadSettings();
    writeFileSync(SETTINGS_F, JSON.stringify({ ...current, ...data }, null, 2));
  } catch (e) {
    console.error('[main] Failed to save settings:', e);
  }
}

// ── MLC Bridge ────────────────────────────────────────────────────────────

let mlcBridge: MLCBridge | null = null;

async function startMLC(): Promise<void> {
  try {
    mlcBridge = new MLCBridge(MLC_DIR);
    registerMLCHandlers(mlcBridge);
    await mlcBridge.start();
    console.log('[main] MLC engine started');
    registerVoicebankHandlers(VOICEBANKS_DIR, mlcBridge);
  } catch (e) {
    console.error('[main] MLC failed to start:', e);
    // App still opens — MLC features just show a "not available" state
  }
}

// ── Window ────────────────────────────────────────────────────────────────

let mainWindow: BrowserWindow | null = null;

function createWindow(): void {
  const settings = loadSettings();
  const bounds   = settings.windowBounds ?? { width: 1280, height: 800 };

  mainWindow = new BrowserWindow({
    ...bounds,
    minWidth:  900,
    minHeight: 600,
    // macOS: native traffic lights, app content under them (hiddenInset)
    // Linux/Windows: fully native frame — OS handles window chrome
    // NEVER fake platform UI elements
    ...(process.platform === 'darwin' ? {
      titleBarStyle:        'hiddenInset' as const,
      trafficLightPosition: { x: 16, y: 11 },
      frame:                true,
    } : {
      frame:           true,
      titleBarStyle:   'default' as const,
      autoHideMenuBar: true,   // hide the native menu bar (our CommandBar replaces it)
    }),
    backgroundColor: settings.isDark ? '#1C1B19' : '#F8F7F4',
    webPreferences: {
      preload:               PRELOAD,
      contextIsolation:      true,   // REQUIRED — renderer cannot access Node
      nodeIntegration:       false,  // REQUIRED — renderer is sandboxed
      sandbox:               false,  // preload needs some Node APIs
      webSecurity:           true,
    },
    show: false, // Show after content loads to avoid white flash
    icon: join(PROJECT_ROOT, 'public', 'icon.png'),
  });

  // Load the app
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(join(DIST_DIR, 'index.html'));  // DIST_DIR = project/dist
  }

  // Show window after first paint — no flash
  mainWindow.once('ready-to-show', () => {
    mainWindow!.show();
    // Send saved UI state to renderer BEFORE first user interaction
    mainWindow!.webContents.send('app:ui-state', loadSettings());
  });

  // Persist window size/position on resize/move
  const persistBounds = () => {
    if (!mainWindow) return;
    saveSettings({ windowBounds: mainWindow.getBounds() });
  };
  mainWindow.on('resize', persistBounds);
  mainWindow.on('moved',  persistBounds);

  // Confirm unsaved changes on close (renderer handles the logic)
  mainWindow.on('close', (e) => {
    // TODO: ask renderer if there are unsaved changes
    // mainWindow?.webContents.send('app:confirm-close');
    // e.preventDefault(); — wire this when project state is implemented
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // Open external links in the system browser, not inside Electron
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http')) shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ── IPC: UI state persistence ─────────────────────────────────────────────
// Renderer sends panel sizes here. We write to settings.json.
// On relaunch, renderer receives them via 'app:ui-state' before first paint.

ipcMain.on('app:save-ui-state', (_, data: Partial<UIState>) => {
  saveSettings(data);
});

ipcMain.handle('app:get-ui-state', () => loadSettings());

// ── IPC: Addon system ─────────────────────────────────────────────────────

/** Get the path to the user's addon directory */
ipcMain.handle('app:get-addons-dir', () => ADDONS_DIR);

/** Open a file picker for .mlc files, install the picked file */
ipcMain.handle('app:install-addon-dialog', async () => {
  if (!mainWindow) return { ok: false, error: 'No window' };
  const result = await dialog.showOpenDialog(mainWindow, {
    title:       'Install Melon Synth Addon',
    buttonLabel: 'Install',
    filters:     [{ name: 'Melon Addon', extensions: ['mlc'] }],
    properties:  ['openFile'],
  });
  if (result.canceled || !result.filePaths.length) {
    return { ok: false, canceled: true };
  }
  return installAddonFromPath(result.filePaths[0]);
});

/** Install from a drag-and-dropped file path */
ipcMain.handle('app:install-addon', async (_, filePath: string) => {
  return installAddonFromPath(filePath);
});

/** Uninstall a named addon — removes from addons dir + notifies MLC */
ipcMain.handle('app:uninstall-addon', async (_, addonId: string) => {
  try {
    const files = require('fs').readdirSync(ADDONS_DIR) as string[];
    const target = files.find((f: string) => f.startsWith(addonId) && f.endsWith('.mlc'));
    if (!target) return { ok: false, error: `Addon "${addonId}" not found in addons directory` };
    require('fs').unlinkSync(join(ADDONS_DIR, target));
    return { ok: true, removed: target };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
});

async function installAddonFromPath(filePath: string): Promise<object> {
  try {
    const filename = require('path').basename(filePath);
    const dest     = join(ADDONS_DIR, filename);

    // Copy to addons dir (unless it's already there)
    if (resolve(filePath) !== resolve(dest)) {
      copyFileSync(filePath, dest);
    }

    // Tell MLC to load it
    if (mlcBridge) {
      const result = await mlcBridge.installAddon(dest);
      return { ok: true, path: dest, result };
    }
    return { ok: true, path: dest, result: 'MLC not running — addon will load on next start' };
  } catch (e: any) {
    return { ok: false, error: e.message };
  }
}

// ── IPC: File dialogs ─────────────────────────────────────────────────────

ipcMain.handle('dialog:open-project', async () => {
  if (!mainWindow) return null;
  const result = await dialog.showOpenDialog(mainWindow, {
    title:   'Open Project',
    filters: [{ name: 'Melon Synth Project', extensions: ['loid'] }],
    properties: ['openFile'],
  });
  return result.canceled ? null : result.filePaths[0];
});

ipcMain.handle('dialog:save-project', async (_, defaultName?: string) => {
  if (!mainWindow) return null;
  const result = await dialog.showSaveDialog(mainWindow, {
    title:       'Save Project',
    defaultPath: defaultName ?? 'untitled.loid',
    filters:     [{ name: 'Melon Synth Project', extensions: ['loid'] }],
  });
  return result.canceled ? null : result.filePath;
});

ipcMain.handle('dialog:export-wav', async (_, defaultName?: string) => {
  if (!mainWindow) return null;
  const result = await dialog.showSaveDialog(mainWindow, {
    title:       'Export WAV',
    defaultPath: defaultName ?? 'export.wav',
    filters:     [{ name: 'WAV Audio', extensions: ['wav'] }],
  });
  return result.canceled ? null : result.filePath;
});

// ── IPC: Shell ────────────────────────────────────────────────────────────

ipcMain.on('shell:open-path', (_, p: string) => shell.openPath(p));

// ── IPC: File read/write (for project save/load) ──────────────────────────
ipcMain.handle('fs:write-file', async (_, filePath: string, content: string) => {
  try {
    const { writeFileSync } = require('fs');
    writeFileSync(filePath, content, 'utf8');
    return { ok: true };
  } catch (e: any) { return { ok: false, error: e.message }; }
});

ipcMain.handle('fs:read-file', async (_, filePath: string) => {
  try {
    const { readFileSync } = require('fs');
    const { join, isAbsolute } = require('path');
    // Handle relative paths (like examples/demo-melody.loid)
    const resolved = isAbsolute(filePath) ? filePath : join(app.getAppPath(), filePath);
    return { ok: true, content: readFileSync(resolved, 'utf8') };
  } catch (e: any) { return { ok: false, error: e.message }; }
});

ipcMain.handle('fs:exists', async (_, filePath: string) => {
  return require('fs').existsSync(filePath);
});
ipcMain.on('shell:open-url',  (_, url: string) => shell.openExternal(url));

// ── IPC: System theme ─────────────────────────────────────────────────────

ipcMain.handle('app:get-system-dark', () => nativeTheme.shouldUseDarkColors);

nativeTheme.on('updated', () => {
  mainWindow?.webContents.send('app:system-dark-changed', nativeTheme.shouldUseDarkColors);
});

// ── IPC: Window controls (Windows/Linux) ─────────────────────────────────

ipcMain.on('win:minimize', () => {
  mainWindow?.minimize();
});

ipcMain.on('win:maximize', () => {
  if (mainWindow?.isMaximized()) {
    mainWindow.unmaximize();
  } else {
    mainWindow?.maximize();
  }
});

ipcMain.on('win:close', () => {
  mainWindow?.close();
});

ipcMain.handle('win:is-maximized', () => {
  return mainWindow?.isMaximized() ?? false;
});

// ── App lifecycle ─────────────────────────────────────────────────────────

app.whenReady().then(async () => {
  await startMLC();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  mlcBridge?.stop();
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  mlcBridge?.stop();
});
