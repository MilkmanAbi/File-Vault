/**
 * Melon Synth — Preload Script
 * ==============================
 * The security boundary. Runs with contextIsolation=true.
 * Whitelists EXACTLY which IPC calls the renderer can make.
 * The renderer has zero direct Node/Electron access — only what's listed here.
 *
 * Think of it like a HAL (Hardware Abstraction Layer) in embedded —
 * the renderer calls clean APIs, has no idea there's IPC underneath.
 *
 * Exposed as:
 *   window.mlc   — all MLC engine operations
 *   window.app   — OS-level app operations (file I/O, dialogs, settings)
 */

import { contextBridge, ipcRenderer } from 'electron';

// ── window.mlc — Melon Lyric Conversion Engine ────────────────────────────

contextBridge.exposeInMainWorld('mlc', {
  /** Test that MLC is alive */
  ping: () =>
    ipcRenderer.invoke('mlc:ping'),

  /** Convert lyrics text → phoneme tokens */
  convert: (params: {
    text:         string;
    moduleId?:    string;
    singability?: number;
    lang?:        string;
  }) =>
    ipcRenderer.invoke('mlc:convert', params),

  /** Fast preview (first 10 words only, cached) */
  preview: (params: {
    text:         string;
    moduleId?:    string;
    singability?: number;
  }) =>
    ipcRenderer.invoke('mlc:preview', params),

  /** List all loaded voicebank modules (built-in + user addons) */
  listModules: () =>
    ipcRenderer.invoke('mlc:list-modules'),

  /** List ALL addons (modules + language packs + pipeline plugins) */
  listAllAddons: () =>
    ipcRenderer.invoke('mlc:list-all-addons'),

  /** Auto-detect the language of a text snippet */
  detectLanguage: (text: string) =>
    ipcRenderer.invoke('mlc:detect-lang', text),

  /** Get a suggested singability value for this text + module combo */
  suggestSingability: (params: { text:string; moduleId?:string; lang?:string }) =>
    ipcRenderer.invoke('mlc:suggest-singability', params),

  /** Cache stats (useful for debugging) */
  cacheStats: () =>
    ipcRenderer.invoke('mlc:cache-stats'),

  /** Clear cache — 'g2p', 'phrase', or 'all' */
  clearCache: (target: 'g2p' | 'phrase' | 'all') =>
    ipcRenderer.invoke('mlc:cache-clear', { target }),
});

// ── window.app — OS-level app operations ─────────────────────────────────

contextBridge.exposeInMainWorld('app', {
  // ── Settings / UI state ────────────────────────────────────────────────
  /** Save panel sizes, dark mode etc to settings.json in OS app-data dir */
  saveUIState: (data: Record<string, unknown>) =>
    ipcRenderer.send('app:save-ui-state', data),

  /** Get the saved UI state (called on startup) */
  getUIState: () =>
    ipcRenderer.invoke('app:get-ui-state'),

  /** Listen for UI state sent at launch (before first paint) */
  onUIState: (cb: (state: Record<string, unknown>) => void) =>
    ipcRenderer.on('app:ui-state', (_event, state) => cb(state)),

  // ── Addon system ───────────────────────────────────────────────────────
  /** Where user addons live on this machine */
  getAddonsDir: () =>
    ipcRenderer.invoke('app:get-addons-dir'),

  /** Open a file picker and install the selected .mlc file */
  installAddonDialog: () =>
    ipcRenderer.invoke('app:install-addon-dialog'),

  /** Install a .mlc file from a known path (drag-and-drop use case) */
  installAddon: (filePath: string) =>
    ipcRenderer.invoke('app:install-addon', filePath),

  /** Remove an installed addon by ID */
  uninstallAddon: (addonId: string) =>
    ipcRenderer.invoke('app:uninstall-addon', addonId),

  // ── File dialogs ───────────────────────────────────────────────────────
  openProject:  () => ipcRenderer.invoke('dialog:open-project'),
  saveProject:  (name?: string) => ipcRenderer.invoke('dialog:save-project', name),
  exportWAV:    (name?: string) => ipcRenderer.invoke('dialog:export-wav', name),

  // ── Shell ──────────────────────────────────────────────────────────────
  /** Open a folder/file in the OS file manager */
  openPath: (p: string) => ipcRenderer.send('shell:open-path', p),
  /** Open a URL in the system browser */
  openURL:  (url: string) => ipcRenderer.send('shell:open-url', url),

  // ── File I/O (for project save/load) ──────────────────────────────────
  writeFile: (path: string, content: string) =>
    ipcRenderer.invoke('fs:write-file', path, content),
  readFile:  (path: string) =>
    ipcRenderer.invoke('fs:read-file', path).then((r: any) => {
      if (!r.ok) throw new Error(r.error);
      return r.content;
    }),
  fileExists: (path: string) =>
    ipcRenderer.invoke('fs:exists', path),

  // ── System theme ───────────────────────────────────────────────────────
  /** Is the OS currently in dark mode? */
  getSystemDark: () => ipcRenderer.invoke('app:get-system-dark'),
  /** Get notified when the OS theme changes */
  onSystemDarkChanged: (cb: (dark: boolean) => void) =>
    ipcRenderer.on('app:system-dark-changed', (_event, dark) => cb(dark)),

  /** Get the current platform (darwin, win32, linux) */
  getPlatform: () => process.platform,
});

// ── window.electron — Low-level window control ─────────────────────────────

contextBridge.exposeInMainWorld('electron', {
  minimize:    () => ipcRenderer.send('win:minimize'),
  maximize:    () => ipcRenderer.send('win:maximize'),
  close:       () => ipcRenderer.send('win:close'),
  isMaximized: () => ipcRenderer.invoke('win:is-maximized'),
  platform:    process.platform,
});

// ── window.voicebanks — voicebank management ─────────────────────────────

contextBridge.exposeInMainWorld('voicebanks', {
  list:           ()                         => ipcRenderer.invoke('vb:list'),
  detectSystem:   ()                         => ipcRenderer.invoke('vb:detect-system'),
  download:       (p: object)                => ipcRenderer.invoke('vb:download', p),
  installFromZip: (zipPath: string)          => ipcRenderer.invoke('vb:install-from-zip', zipPath),
  openFolder:     (p: string)                => ipcRenderer.send('vb:open-folder', p),

  /** Progress events from download/extract */
  onDownloadProgress: (cb: (p: object) => void) =>
    ipcRenderer.on('vb:download-progress', (_e, p) => cb(p)),
});

// ── window.render — synthesis + music editor bridge ──────────────────────

contextBridge.exposeInMainWorld('render', {
  generateUST:    (p: object) => ipcRenderer.invoke('render:generate-ust', p),
  render:         (p: object) => ipcRenderer.invoke('render:render', p),
  detectEditors:  ()          => ipcRenderer.invoke('editor:detect'),
  openInEditor:   (p: object) => ipcRenderer.invoke('editor:open', p),

  onComplete:     (cb: (r: object) => void) =>
    ipcRenderer.on('render:complete', (_e, r) => cb(r)),
  onError:        (cb: (e: object) => void) =>
    ipcRenderer.on('render:error',    (_e, e) => cb(e)),
});

// ── TypeScript type declarations (used by renderer) ───────────────────────
// These are declared in src/types/electron.d.ts so the React app has types.

// Expose platform so TitleBar knows whether to render
// Platform exposed via contextBridge above as window.__melonPlatform

export {};
