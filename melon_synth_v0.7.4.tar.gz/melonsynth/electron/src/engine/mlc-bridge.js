"use strict";
/**
 * MLC Bridge — Electron Main Process
 * ====================================
 * Spawns the MLC Python engine as a child process.
 * Communicates via newline-delimited JSON over stdin/stdout.
 *
 * Usage (from renderer via preload/ipcRenderer):
 *   const result = await window.mlc.convert({ text, moduleId, singability })
 *   const modules = await window.mlc.listModules()
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.MLCBridge = void 0;
exports.registerMLCHandlers = registerMLCHandlers;
const child_process_1 = require("child_process");
const electron_1 = require("electron");
const path_1 = require("path");
const crypto_1 = require("crypto");
const events_1 = require("events");
class MLCBridge extends events_1.EventEmitter {
    constructor(engineDir) {
        super();
        this.proc = null;
        this.pending = new Map();
        this.buffer = '';
        this.ready = false;
        this.REQUEST_TIMEOUT = 15000; // 15s max per request
        this.enginePath = (0, path_1.join)(engineDir, 'mlc_engine_v2.py');
    }
    // ── Lifecycle ────────────────────────────────────────────────────────────
    async start() {
        if (this.proc)
            return;
        return new Promise((resolve, reject) => {
            const python = process.platform === 'win32' ? 'python' : 'python3';
            this.proc = (0, child_process_1.spawn)(python, [this.enginePath], {
                cwd: require('path').dirname(this.enginePath),
                stdio: ['pipe', 'pipe', 'pipe'],
            });
            if (!this.proc.stdout || !this.proc.stdin || !this.proc.stderr) {
                reject(new Error('Failed to open MLC process stdio'));
                return;
            }
            // Read newline-delimited JSON from stdout
            this.proc.stdout.setEncoding('utf8');
            this.proc.stdout.on('data', (chunk) => {
                this.buffer += chunk;
                const lines = this.buffer.split('\n');
                this.buffer = lines.pop() ?? '';
                for (const line of lines) {
                    const trimmed = line.trim();
                    if (trimmed)
                        this.handleMessage(trimmed);
                }
            });
            // Log stderr without crashing
            this.proc.stderr.setEncoding('utf8');
            this.proc.stderr.on('data', (data) => {
                if (process.env.NODE_ENV === 'development') {
                    console.error('[MLC stderr]', data.trim());
                }
            });
            this.proc.on('error', (err) => {
                this.emit('error', err);
                reject(err);
            });
            this.proc.on('exit', (code) => {
                this.ready = false;
                this.proc = null;
                // Reject all pending requests
                for (const [id, req] of this.pending) {
                    clearTimeout(req.timeout);
                    req.reject(new Error(`MLC process exited with code ${code}`));
                }
                this.pending.clear();
                this.emit('exit', code);
            });
            // Ping to verify it started
            setTimeout(async () => {
                try {
                    await this.ping();
                    this.ready = true;
                    resolve();
                }
                catch (e) {
                    reject(new Error('MLC engine did not respond to ping. ' +
                        'Make sure Python 3.9+ is installed and ' +
                        'dependencies are installed (see mlc/requirements.txt).'));
                }
            }, 500);
        });
    }
    stop() {
        if (this.proc) {
            this.proc.kill('SIGTERM');
            this.proc = null;
        }
    }
    // ── Core IPC ─────────────────────────────────────────────────────────────
    send(msg) {
        if (!this.proc?.stdin)
            throw new Error('MLC not running');
        this.proc.stdin.write(JSON.stringify(msg) + '\n');
    }
    /** Public for main-process callers (voicebank-manager etc). Never expose to renderer. */
    request(action, params = {}) {
        return new Promise((resolve, reject) => {
            const id = (0, crypto_1.randomUUID)();
            const timeout = setTimeout(() => {
                this.pending.delete(id);
                reject(new Error(`MLC request "${action}" timed out after ${this.REQUEST_TIMEOUT}ms`));
            }, this.REQUEST_TIMEOUT);
            this.pending.set(id, { resolve, reject, timeout });
            this.send({ id, action, ...params });
        });
    }
    handleMessage(raw) {
        let msg;
        try {
            msg = JSON.parse(raw);
        }
        catch {
            console.error('[MLC] Invalid JSON from engine:', raw);
            return;
        }
        const req = this.pending.get(msg.id);
        if (!req)
            return;
        clearTimeout(req.timeout);
        this.pending.delete(msg.id);
        if (msg.ok) {
            req.resolve(msg.data);
        }
        else {
            req.reject(new Error(msg.error ?? 'Unknown MLC error'));
        }
    }
    // ── Public API ───────────────────────────────────────────────────────────
    async ping() {
        return this.request('ping');
    }
    async listModules() {
        return this.request('list_modules');
    }
    async detectLanguage(text) {
        return this.request('detect_lang', { text });
    }
    async convert(params) {
        return this.request('convert', {
            text: params.text,
            module_id: params.moduleId ?? 'jp_cv_standard',
            singability: params.singability ?? 0.5,
            lang: params.lang ?? null,
        });
    }
    async preview(params) {
        return this.request('preview', {
            text: params.text,
            module_id: params.moduleId ?? 'jp_cv_standard',
            singability: params.singability ?? 0.5,
        });
    }
    async listAllAddons() {
        return this.request('list_all_addons');
    }
    async suggestSingability(params) {
        return this.request('suggest_singability', {
            text: params.text,
            module_id: params.moduleId ?? 'jp_cv_standard',
            lang: params.lang ?? null,
        });
    }
    async cacheStats() {
        return this.request('cache_stats');
    }
    async clearCache(target) {
        return this.request('cache_clear', { target });
    }
    /** Install a .mlc bundle file from an absolute path on disk */
    async installAddon(filePath) {
        return this.request('install_module', { path: filePath });
    }
    async reloadAddon(moduleId) {
        return this.request('reload_module', { module_id: moduleId });
    }
}
exports.MLCBridge = MLCBridge;
// ── Electron IPC handlers (register in main process) ─────────────────────
function registerMLCHandlers(bridge) {
    electron_1.ipcMain.handle('mlc:ping', () => bridge.ping());
    electron_1.ipcMain.handle('mlc:convert', (_, p) => bridge.convert(p));
    electron_1.ipcMain.handle('mlc:preview', (_, p) => bridge.preview(p));
    electron_1.ipcMain.handle('mlc:list-modules', () => bridge.listModules());
    electron_1.ipcMain.handle('mlc:list-all-addons', () => bridge.listAllAddons());
    electron_1.ipcMain.handle('mlc:detect-lang', (_, text) => bridge.detectLanguage(text));
    electron_1.ipcMain.handle('mlc:suggest-singability', (_, p) => bridge.suggestSingability(p));
    electron_1.ipcMain.handle('mlc:cache-stats', () => bridge.cacheStats());
    electron_1.ipcMain.handle('mlc:cache-clear', (_, p) => bridge.clearCache(p.target));
}
//# sourceMappingURL=mlc-bridge.js.map