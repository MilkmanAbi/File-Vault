"use strict";
/**
 * Melon Synth — Preload Script
 * ==============================
 * The security boundary. Runs with contextIsolation=true.
 * Whitelists EXACTLY which IPC calls the renderer can make.
 * The renderer has zero direct Node/Electron access — only what's listed here.
 *
 * Think of it like a HAL (Hardware Abstraction Layer) in embedded —
 * the renderer calls clean APIs, has no idea there's IPC underneath.
 *
 * Exposed as:
 *   window.mlc   — all MLC engine operations
 *   window.app   — OS-level app operations (file I/O, dialogs, settings)
 */
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
// ── window.mlc — Melon Lyric Conversion Engine ────────────────────────────
electron_1.contextBridge.exposeInMainWorld('mlc', {
    /** Test that MLC is alive */
    ping: () => electron_1.ipcRenderer.invoke('mlc:ping'),
    /** Convert lyrics text → phoneme tokens */
    convert: (params) => electron_1.ipcRenderer.invoke('mlc:convert', params),
    /** Fast preview (first 10 words only, cached) */
    preview: (params) => electron_1.ipcRenderer.invoke('mlc:preview', params),
    /** List all loaded voicebank modules (built-in + user addons) */
    listModules: () => electron_1.ipcRenderer.invoke('mlc:list-modules'),
    /** List ALL addons (modules + language packs + pipeline plugins) */
    listAllAddons: () => electron_1.ipcRenderer.invoke('mlc:list-all-addons'),
    /** Auto-detect the language of a text snippet */
    detectLanguage: (text) => electron_1.ipcRenderer.invoke('mlc:detect-lang', text),
    /** Get a suggested singability value for this text + module combo */
    suggestSingability: (params) => electron_1.ipcRenderer.invoke('mlc:suggest-singability', params),
    /** Cache stats (useful for debugging) */
    cacheStats: () => electron_1.ipcRenderer.invoke('mlc:cache-stats'),
    /** Clear cache — 'g2p', 'phrase', or 'all' */
    clearCache: (target) => electron_1.ipcRenderer.invoke('mlc:cache-clear', { target }),
});
// ── window.app — OS-level app operations ─────────────────────────────────
electron_1.contextBridge.exposeInMainWorld('app', {
    // ── Settings / UI state ────────────────────────────────────────────────
    /** Save panel sizes, dark mode etc to settings.json in OS app-data dir */
    saveUIState: (data) => electron_1.ipcRenderer.send('app:save-ui-state', data),
    /** Get the saved UI state (called on startup) */
    getUIState: () => electron_1.ipcRenderer.invoke('app:get-ui-state'),
    /** Listen for UI state sent at launch (before first paint) */
    onUIState: (cb) => electron_1.ipcRenderer.on('app:ui-state', (_event, state) => cb(state)),
    // ── Addon system ───────────────────────────────────────────────────────
    /** Where user addons live on this machine */
    getAddonsDir: () => electron_1.ipcRenderer.invoke('app:get-addons-dir'),
    /** Open a file picker and install the selected .mlc file */
    installAddonDialog: () => electron_1.ipcRenderer.invoke('app:install-addon-dialog'),
    /** Install a .mlc file from a known path (drag-and-drop use case) */
    installAddon: (filePath) => electron_1.ipcRenderer.invoke('app:install-addon', filePath),
    /** Remove an installed addon by ID */
    uninstallAddon: (addonId) => electron_1.ipcRenderer.invoke('app:uninstall-addon', addonId),
    // ── File dialogs ───────────────────────────────────────────────────────
    openProject: () => electron_1.ipcRenderer.invoke('dialog:open-project'),
    saveProject: (name) => electron_1.ipcRenderer.invoke('dialog:save-project', name),
    exportWAV: (name) => electron_1.ipcRenderer.invoke('dialog:export-wav', name),
    // ── Shell ──────────────────────────────────────────────────────────────
    /** Open a folder/file in the OS file manager */
    openPath: (p) => electron_1.ipcRenderer.send('shell:open-path', p),
    /** Open a URL in the system browser */
    openURL: (url) => electron_1.ipcRenderer.send('shell:open-url', url),
    // ── File I/O (for project save/load) ──────────────────────────────────
    writeFile: (path, content) => electron_1.ipcRenderer.invoke('fs:write-file', path, content),
    readFile: (path) => electron_1.ipcRenderer.invoke('fs:read-file', path).then((r) => {
        if (!r.ok)
            throw new Error(r.error);
        return r.content;
    }),
    fileExists: (path) => electron_1.ipcRenderer.invoke('fs:exists', path),
    // ── System theme ───────────────────────────────────────────────────────
    /** Is the OS currently in dark mode? */
    getSystemDark: () => electron_1.ipcRenderer.invoke('app:get-system-dark'),
    /** Get notified when the OS theme changes */
    onSystemDarkChanged: (cb) => electron_1.ipcRenderer.on('app:system-dark-changed', (_event, dark) => cb(dark)),
    /** Get the current platform (darwin, win32, linux) */
    getPlatform: () => process.platform,
});
// ── window.electron — Low-level window control ─────────────────────────────
electron_1.contextBridge.exposeInMainWorld('electron', {
    minimize: () => electron_1.ipcRenderer.send('win:minimize'),
    maximize: () => electron_1.ipcRenderer.send('win:maximize'),
    close: () => electron_1.ipcRenderer.send('win:close'),
    isMaximized: () => electron_1.ipcRenderer.invoke('win:is-maximized'),
    platform: process.platform,
});
// ── window.voicebanks — voicebank management ─────────────────────────────
electron_1.contextBridge.exposeInMainWorld('voicebanks', {
    list: () => electron_1.ipcRenderer.invoke('vb:list'),
    detectSystem: () => electron_1.ipcRenderer.invoke('vb:detect-system'),
    download: (p) => electron_1.ipcRenderer.invoke('vb:download', p),
    installFromZip: (zipPath) => electron_1.ipcRenderer.invoke('vb:install-from-zip', zipPath),
    openFolder: (p) => electron_1.ipcRenderer.send('vb:open-folder', p),
    /** Progress events from download/extract */
    onDownloadProgress: (cb) => electron_1.ipcRenderer.on('vb:download-progress', (_e, p) => cb(p)),
});
// ── window.render — synthesis + music editor bridge ──────────────────────
electron_1.contextBridge.exposeInMainWorld('render', {
    generateUST: (p) => electron_1.ipcRenderer.invoke('render:generate-ust', p),
    render: (p) => electron_1.ipcRenderer.invoke('render:render', p),
    detectEditors: () => electron_1.ipcRenderer.invoke('editor:detect'),
    openInEditor: (p) => electron_1.ipcRenderer.invoke('editor:open', p),
    onComplete: (cb) => electron_1.ipcRenderer.on('render:complete', (_e, r) => cb(r)),
    onError: (cb) => electron_1.ipcRenderer.on('render:error', (_e, e) => cb(e)),
});
//# sourceMappingURL=preload.js.map