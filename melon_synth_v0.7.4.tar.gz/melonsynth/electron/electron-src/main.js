"use strict";
/**
 * Melon Synth — Electron Main Process
 * =====================================
 * The supervisor. Has full OS access.
 * Manages: window lifetime, MLC bridge, addon installs,
 *          file dialogs, settings persistence, IPC routing.
 *
 * Architecture:
 *   Renderer (React)  ←→  preload.ts (whitelist)  ←→  main.ts  ←→  Python MLC
 *
 * The MLC Python process is spawned ONCE when the window opens.
 * It lives until the app quits. All conversion/install requests go through it.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = require("path");
const fs_1 = require("fs");
const mlc_bridge_1 = require("../src/engine/mlc-bridge");
const voicebank_manager_1 = require("./voicebank-manager");
// ── Paths ─────────────────────────────────────────────────────────────────
// __dirname after compilation = <project>/electron/electron-src/
// PROJECT_ROOT goes up two levels to the repo root.
const isDev = process.env.NODE_ENV === 'development' || !electron_1.app.isPackaged;
const PROJECT_ROOT = (0, path_1.join)(__dirname, '..', '..'); // electron/electron-src → project root
const DIST_DIR = (0, path_1.join)(PROJECT_ROOT, 'dist');
const PRELOAD = (0, path_1.join)(__dirname, 'preload.js'); // same dir as main.js ✓
// User data paths — persisted across sessions, never wiped by browser clears
const USER_DATA = electron_1.app.getPath('userData');
const SETTINGS_F = (0, path_1.join)(USER_DATA, 'settings.json');
const ADDONS_DIR = (0, path_1.join)(USER_DATA, 'addons');
const PROJECTS_DIR = (0, path_1.join)(USER_DATA, 'projects');
const VOICEBANKS_DIR = (0, path_1.join)(USER_DATA, 'voicebanks');
// MLC engine location
// In dev: relative to repo. In production: in extraResources.
const MLC_DIR = electron_1.app.isPackaged
    ? (0, path_1.join)(process.resourcesPath, 'mlc')
    : (0, path_1.join)(PROJECT_ROOT, 'mlc');
// ── Ensure dirs exist ─────────────────────────────────────────────────────
[USER_DATA, ADDONS_DIR, PROJECTS_DIR, VOICEBANKS_DIR].forEach(d => {
    if (!(0, fs_1.existsSync)(d))
        (0, fs_1.mkdirSync)(d, { recursive: true });
});
function loadSettings() {
    try {
        return JSON.parse((0, fs_1.readFileSync)(SETTINGS_F, 'utf8'));
    }
    catch {
        return {};
    }
}
function saveSettings(data) {
    try {
        const current = loadSettings();
        (0, fs_1.writeFileSync)(SETTINGS_F, JSON.stringify({ ...current, ...data }, null, 2));
    }
    catch (e) {
        console.error('[main] Failed to save settings:', e);
    }
}
// ── MLC Bridge ────────────────────────────────────────────────────────────
let mlcBridge = null;
async function startMLC() {
    try {
        mlcBridge = new mlc_bridge_1.MLCBridge(MLC_DIR);
        (0, mlc_bridge_1.registerMLCHandlers)(mlcBridge);
        await mlcBridge.start();
        console.log('[main] MLC engine started');
        (0, voicebank_manager_1.registerVoicebankHandlers)(VOICEBANKS_DIR, mlcBridge);
    }
    catch (e) {
        console.error('[main] MLC failed to start:', e);
        // App still opens — MLC features just show a "not available" state
    }
}
// ── Window ────────────────────────────────────────────────────────────────
let mainWindow = null;
function createWindow() {
    const settings = loadSettings();
    const bounds = settings.windowBounds ?? { width: 1280, height: 800 };
    mainWindow = new electron_1.BrowserWindow({
        ...bounds,
        minWidth: 900,
        minHeight: 600,
        // macOS: native traffic lights, app content under them (hiddenInset)
        // Linux/Windows: fully native frame — OS handles window chrome
        // NEVER fake platform UI elements
        ...(process.platform === 'darwin' ? {
            titleBarStyle: 'hiddenInset',
            trafficLightPosition: { x: 16, y: 11 },
            frame: true,
        } : {
            frame: true,
            titleBarStyle: 'default',
            autoHideMenuBar: true, // hide the native menu bar (our CommandBar replaces it)
        }),
        backgroundColor: settings.isDark ? '#1C1B19' : '#F8F7F4',
        webPreferences: {
            preload: PRELOAD,
            contextIsolation: true, // REQUIRED — renderer cannot access Node
            nodeIntegration: false, // REQUIRED — renderer is sandboxed
            sandbox: false, // preload needs some Node APIs
            webSecurity: true,
        },
        show: false, // Show after content loads to avoid white flash
        icon: (0, path_1.join)(PROJECT_ROOT, 'public', 'icon.png'),
    });
    // Load the app
    if (isDev) {
        mainWindow.loadURL('http://localhost:5173');
        mainWindow.webContents.openDevTools({ mode: 'detach' });
    }
    else {
        mainWindow.loadFile((0, path_1.join)(DIST_DIR, 'index.html')); // DIST_DIR = project/dist
    }
    // Show window after first paint — no flash
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        // Send saved UI state to renderer BEFORE first user interaction
        mainWindow.webContents.send('app:ui-state', loadSettings());
    });
    // Persist window size/position on resize/move
    const persistBounds = () => {
        if (!mainWindow)
            return;
        saveSettings({ windowBounds: mainWindow.getBounds() });
    };
    mainWindow.on('resize', persistBounds);
    mainWindow.on('moved', persistBounds);
    // Confirm unsaved changes on close (renderer handles the logic)
    mainWindow.on('close', (e) => {
        // TODO: ask renderer if there are unsaved changes
        // mainWindow?.webContents.send('app:confirm-close');
        // e.preventDefault(); — wire this when project state is implemented
    });
    mainWindow.on('closed', () => { mainWindow = null; });
    // Open external links in the system browser, not inside Electron
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        if (url.startsWith('http'))
            electron_1.shell.openExternal(url);
        return { action: 'deny' };
    });
}
// ── IPC: UI state persistence ─────────────────────────────────────────────
// Renderer sends panel sizes here. We write to settings.json.
// On relaunch, renderer receives them via 'app:ui-state' before first paint.
electron_1.ipcMain.on('app:save-ui-state', (_, data) => {
    saveSettings(data);
});
electron_1.ipcMain.handle('app:get-ui-state', () => loadSettings());
// ── IPC: Addon system ─────────────────────────────────────────────────────
/** Get the path to the user's addon directory */
electron_1.ipcMain.handle('app:get-addons-dir', () => ADDONS_DIR);
/** Open a file picker for .mlc files, install the picked file */
electron_1.ipcMain.handle('app:install-addon-dialog', async () => {
    if (!mainWindow)
        return { ok: false, error: 'No window' };
    const result = await electron_1.dialog.showOpenDialog(mainWindow, {
        title: 'Install Melon Synth Addon',
        buttonLabel: 'Install',
        filters: [{ name: 'Melon Addon', extensions: ['mlc'] }],
        properties: ['openFile'],
    });
    if (result.canceled || !result.filePaths.length) {
        return { ok: false, canceled: true };
    }
    return installAddonFromPath(result.filePaths[0]);
});
/** Install from a drag-and-dropped file path */
electron_1.ipcMain.handle('app:install-addon', async (_, filePath) => {
    return installAddonFromPath(filePath);
});
/** Uninstall a named addon — removes from addons dir + notifies MLC */
electron_1.ipcMain.handle('app:uninstall-addon', async (_, addonId) => {
    try {
        const files = require('fs').readdirSync(ADDONS_DIR);
        const target = files.find((f) => f.startsWith(addonId) && f.endsWith('.mlc'));
        if (!target)
            return { ok: false, error: `Addon "${addonId}" not found in addons directory` };
        require('fs').unlinkSync((0, path_1.join)(ADDONS_DIR, target));
        return { ok: true, removed: target };
    }
    catch (e) {
        return { ok: false, error: e.message };
    }
});
async function installAddonFromPath(filePath) {
    try {
        const filename = require('path').basename(filePath);
        const dest = (0, path_1.join)(ADDONS_DIR, filename);
        // Copy to addons dir (unless it's already there)
        if ((0, path_1.resolve)(filePath) !== (0, path_1.resolve)(dest)) {
            (0, fs_1.copyFileSync)(filePath, dest);
        }
        // Tell MLC to load it
        if (mlcBridge) {
            const result = await mlcBridge.installAddon(dest);
            return { ok: true, path: dest, result };
        }
        return { ok: true, path: dest, result: 'MLC not running — addon will load on next start' };
    }
    catch (e) {
        return { ok: false, error: e.message };
    }
}
// ── IPC: File dialogs ─────────────────────────────────────────────────────
electron_1.ipcMain.handle('dialog:open-project', async () => {
    if (!mainWindow)
        return null;
    const result = await electron_1.dialog.showOpenDialog(mainWindow, {
        title: 'Open Project',
        filters: [{ name: 'Melon Synth Project', extensions: ['loid'] }],
        properties: ['openFile'],
    });
    return result.canceled ? null : result.filePaths[0];
});
electron_1.ipcMain.handle('dialog:save-project', async (_, defaultName) => {
    if (!mainWindow)
        return null;
    const result = await electron_1.dialog.showSaveDialog(mainWindow, {
        title: 'Save Project',
        defaultPath: defaultName ?? 'untitled.loid',
        filters: [{ name: 'Melon Synth Project', extensions: ['loid'] }],
    });
    return result.canceled ? null : result.filePath;
});
electron_1.ipcMain.handle('dialog:export-wav', async (_, defaultName) => {
    if (!mainWindow)
        return null;
    const result = await electron_1.dialog.showSaveDialog(mainWindow, {
        title: 'Export WAV',
        defaultPath: defaultName ?? 'export.wav',
        filters: [{ name: 'WAV Audio', extensions: ['wav'] }],
    });
    return result.canceled ? null : result.filePath;
});
// ── IPC: Shell ────────────────────────────────────────────────────────────
electron_1.ipcMain.on('shell:open-path', (_, p) => electron_1.shell.openPath(p));
// ── IPC: File read/write (for project save/load) ──────────────────────────
electron_1.ipcMain.handle('fs:write-file', async (_, filePath, content) => {
    try {
        const { writeFileSync } = require('fs');
        writeFileSync(filePath, content, 'utf8');
        return { ok: true };
    }
    catch (e) {
        return { ok: false, error: e.message };
    }
});
electron_1.ipcMain.handle('fs:read-file', async (_, filePath) => {
    try {
        const { readFileSync } = require('fs');
        const { join, isAbsolute } = require('path');
        // Handle relative paths (like examples/demo-melody.loid)
        const resolved = isAbsolute(filePath) ? filePath : join(electron_1.app.getAppPath(), filePath);
        return { ok: true, content: readFileSync(resolved, 'utf8') };
    }
    catch (e) {
        return { ok: false, error: e.message };
    }
});
electron_1.ipcMain.handle('fs:exists', async (_, filePath) => {
    return require('fs').existsSync(filePath);
});
electron_1.ipcMain.on('shell:open-url', (_, url) => electron_1.shell.openExternal(url));
// ── IPC: System theme ─────────────────────────────────────────────────────
electron_1.ipcMain.handle('app:get-system-dark', () => electron_1.nativeTheme.shouldUseDarkColors);
electron_1.nativeTheme.on('updated', () => {
    mainWindow?.webContents.send('app:system-dark-changed', electron_1.nativeTheme.shouldUseDarkColors);
});
// ── IPC: Window controls (Windows/Linux) ─────────────────────────────────
electron_1.ipcMain.on('win:minimize', () => {
    mainWindow?.minimize();
});
electron_1.ipcMain.on('win:maximize', () => {
    if (mainWindow?.isMaximized()) {
        mainWindow.unmaximize();
    }
    else {
        mainWindow?.maximize();
    }
});
electron_1.ipcMain.on('win:close', () => {
    mainWindow?.close();
});
electron_1.ipcMain.handle('win:is-maximized', () => {
    return mainWindow?.isMaximized() ?? false;
});
// ── App lifecycle ─────────────────────────────────────────────────────────
electron_1.app.whenReady().then(async () => {
    await startMLC();
    createWindow();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0)
            createWindow();
    });
});
electron_1.app.on('window-all-closed', () => {
    mlcBridge?.stop();
    if (process.platform !== 'darwin')
        electron_1.app.quit();
});
electron_1.app.on('before-quit', () => {
    mlcBridge?.stop();
});
//# sourceMappingURL=main.js.map