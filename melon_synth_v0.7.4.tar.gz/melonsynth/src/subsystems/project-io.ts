/**
 * Project I/O Subsystem
 * =====================
 * Handles .loid project files.
 *
 * .loid format: ZIP archive containing JSON files.
 * In Electron: uses native file dialogs + fs.
 * In browser dev: uses localStorage + JSON download.
 */

import type { Note, PitchPoint, VoiceTrack } from '../store/project';

export interface LoidProject {
  version:      '1.0';
  name:         string;
  bpm:          number;
  timeSig:      [number, number];
  tracks:       VoiceTrack[];
  notes:        Note[];
  pitchPoints:  PitchPoint[];
  createdAt:    string;
  modifiedAt:   string;
}

const CURRENT_VERSION = '1.0' as const;

export function serializeProject(
  name: string,
  bpm: number,
  tracks: VoiceTrack[],
  notes: Note[],
  pitchPoints: PitchPoint[],
): LoidProject {
  return {
    version:     CURRENT_VERSION,
    name,
    bpm,
    timeSig:     [4, 4],
    tracks:      tracks.map(t => ({ ...t })),
    notes:       notes.map(n => ({ ...n, playing: false, selected: false })),
    pitchPoints: pitchPoints.map(p => ({ ...p, selected: false })),
    createdAt:   new Date().toISOString(),
    modifiedAt:  new Date().toISOString(),
  };
}

export function deserializeProject(data: unknown): LoidProject | null {
  if (!data || typeof data !== 'object') return null;
  const d = data as Record<string, unknown>;
  if (d.version !== CURRENT_VERSION) {
    console.warn('[project-io] Unknown version:', d.version);
  }
  return d as unknown as LoidProject;
}

// ── Electron path ────────────────────────────────────────────────────────────

const isElectron = typeof window !== 'undefined' && !!(window as any).app;

export async function saveProject(
  project: LoidProject,
  filePath?: string | null,
): Promise<string | null> {
  const json = JSON.stringify(project, null, 2);

  if (isElectron) {
    const path = filePath ?? await (window as any).app.saveProject(project.name + '.loid');
    if (!path) return null;
    // Electron main process handles actual file write via IPC
    await (window as any).app.writeFile(path, json);
    return path;
  }

  // Browser fallback: download as JSON
  const blob = new Blob([json], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `${project.name}.loid`;
  a.click();
  URL.revokeObjectURL(url);
  return project.name + '.loid';
}

export async function openProject(): Promise<LoidProject | null> {
  if (isElectron) {
    const path = await (window as any).app.openProject();
    if (!path) return null;
    const json = await (window as any).app.readFile(path);
    return deserializeProject(JSON.parse(json));
  }

  // Browser fallback: file input picker
  return new Promise(resolve => {
    const input  = document.createElement('input');
    input.type   = 'file';
    input.accept = '.loid,.json';
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return resolve(null);
      const text = await file.text();
      resolve(deserializeProject(JSON.parse(text)));
    };
    input.click();
  });
}

export function newProject(name = 'untitled'): LoidProject {
  return {
    version:     CURRENT_VERSION,
    name,
    bpm:         132,
    timeSig:     [4, 4],
    tracks:      [
      { id:'t1', name:'Track 1', voiceBank:'', engine:'OpenUTAU',
        color:'#4DBF90', muted:false, selected:true },
    ],
    notes:       [],
    pitchPoints: [],
    createdAt:   new Date().toISOString(),
    modifiedAt:  new Date().toISOString(),
  };
}
