# Cantonese Language Pack for Melon Synth

Converts Cantonese (Traditional/Simplified Chinese) lyrics to the phoneme sequences
a vocaloid voicebank can sing, using Jyutping romanisation.

## Features
- 6-tone system (陰平 陰上 陰去 陽平 陽上 陽去)
- Tone curves passed to ToneAwarePitch plugin automatically
- Full G2P when `pycantonese` is installed
- Lookup table fallback (~500 common characters) when it isn't
- Works with any JP CV or CVVC voicebank in combination with a JP mapper

## Usage
1. Install this addon in Melon Synth
2. Select "Cantonese" as the source language
3. Pair with a JP CV or CVVC voicebank mapper
4. Type Cantonese lyrics in Traditional or Simplified Chinese

## Dependencies
```
pip install pycantonese
```
Without pycantonese, common characters still work via the built-in lookup table.

## Tone reference
| Tone | Name     | Jyutping | Example |
|------|----------|----------|---------|
| 1    | 陰平 (high level)   | si1 | 詩 |
| 2    | 陰上 (high rising)  | si2 | 史 |
| 3    | 陰去 (mid level)    | si3 | 試 |
| 4    | 陽平 (low falling)  | si4 | 時 |
| 5    | 陽上 (low rising)   | si5 | 市 |
| 6    | 陽去 (low level)    | si6 | 事 |
