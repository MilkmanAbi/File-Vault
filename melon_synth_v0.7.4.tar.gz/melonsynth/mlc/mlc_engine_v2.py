#!/usr/bin/env python3
"""
MLC Engine v2 — Melon Lyric Conversion Engine
==============================================
The IPC server. Electron spawns this once, keeps it running.
Communicates via newline-delimited JSON on stdin/stdout.

New in v2:
  - Core pipeline split into proper modules (core/)
  - Registry with .mlc bundle support + hot-reload
  - G2P cache (SQLite, massive perf improvement)
  - Phrase cache (full result caching)
  - Confidence scoring with per-token indicators
  - Language auto-detection
  - Multiple language support via espeak-ng

Install:
  pip install phonemizer langdetect nltk
  [system] apt install espeak-ng   (or brew/winget equivalent)

Run standalone test:
  echo '{"id":"t1","action":"convert","text":"beautiful dream","module_id":"jp_cv_standard","singability":0.6}' | python mlc_engine_v2.py
"""

import sys
import os
import json
import logging
import traceback
import time
from pathlib import Path

# Render subsystem (lazy-loaded to keep startup fast)
_render_bridge = None
_ust_gen = None
def _get_render():
    global _render_bridge, _ust_gen
    if _render_bridge is None:
        sys.path.insert(0, str(ROOT / 'render'))
        from render_bridge import (
            find_openutau, find_singers_dir, list_installed_voicebanks,
            detect_music_editors, open_in_editor, render as do_render,
        )
        from ust_generator import write_ust_file, generate_ust
        _render_bridge = {
            'find_openutau':           find_openutau,
            'find_singers_dir':        find_singers_dir,
            'list_installed_voicebanks': list_installed_voicebanks,
            'detect_music_editors':    detect_music_editors,
            'open_in_editor':          open_in_editor,
            'render':                  do_render,
            'write_ust_file':          write_ust_file,
            'generate_ust':            generate_ust,
        }

    return _render_bridge

# ── Path setup ────────────────────────────────────────────────────────────

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'core'))

# ── Logging ───────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format='[MLC %(levelname)s %(name)s] %(message)s',
    stream=sys.stderr,
)
log = logging.getLogger('mlc')

# ── Config ────────────────────────────────────────────────────────────────

BUILTIN_MODULES_DIR = ROOT / 'modules'
USER_MODULES_DIR    = Path(os.environ.get('MLC_MODULES_DIR', ROOT / 'user_modules'))
CACHE_DIR           = Path(os.environ.get('MLC_CACHE_DIR',  ROOT / '.cache'))

USER_MODULES_DIR.mkdir(exist_ok=True)
CACHE_DIR.mkdir(exist_ok=True)

# ── Lazy globals ──────────────────────────────────────────────────────────

_registry  = None
_g2p       = None
_g2p_cache = None
_p_cache   = None
_scorer    = None


def get_registry():
    global _registry
    if _registry is None:
        from registry import MLCRegistry
        _registry = MLCRegistry(BUILTIN_MODULES_DIR, USER_MODULES_DIR)
        _registry.discover_all()
        _registry.start_watching()
    return _registry


def get_g2p():
    global _g2p
    if _g2p is None:
        from core.g2p import G2PEngine
        _g2p = G2PEngine()
    return _g2p


def get_g2p_cache():
    global _g2p_cache
    if _g2p_cache is None:
        from core.cache import G2PCache
        _g2p_cache = G2PCache(CACHE_DIR / 'g2p.db')
    return _g2p_cache


def get_phrase_cache():
    global _p_cache
    if _p_cache is None:
        from core.cache import PhraseCache
        _p_cache = PhraseCache(CACHE_DIR / 'phrases.db')
    return _p_cache


def get_scorer():
    global _scorer
    if _scorer is None:
        from core.confidence import ConfidenceScorer
        _scorer = ConfidenceScorer()
    return _scorer


# ── Action handlers ───────────────────────────────────────────────────────

def handle_ping(_msg: dict):
    return {
        'status':  'ok',
        'version': '2.0.0',
        'api':     '1.0.0',
        'modules': len(get_registry()._modules),
        'cache':   get_g2p_cache().stats(),
    }


def handle_list_modules(_msg: dict):
    return get_registry().list_all()


def handle_detect_lang(msg: dict):
    text = msg.get('text', '').strip()
    if not text:
        return {'lang': 'en', 'confidence': 0.0}
    try:
        from langdetect import detect_langs
        results = detect_langs(text)
        if results:
            return {
                'lang':       results[0].lang,
                'confidence': round(results[0].prob, 3),
                'all':        [{'lang': r.lang, 'prob': round(r.prob, 3)} for r in results],
            }
    except Exception:
        pass
    return {'lang': 'en', 'confidence': 0.5}


def handle_install_module(msg: dict):
    """Install a .mlc bundle from a file path."""
    path_str = msg.get('path', '')
    if not path_str:
        raise ValueError('path is required')
    path = Path(path_str)
    if not path.exists():
        raise FileNotFoundError(f'File not found: {path}')
    if path.suffix.lower() != '.mlc':
        raise ValueError(f'Not a .mlc file: {path.name}')
    result = get_registry().install_bundle(path)
    return {'status': result, 'path': str(path)}


def handle_list_all_addons(_msg: dict):
    """List every addon type — voicebank mappers, language packs, pipeline plugins."""
    from addon_registry import AddonRegistry
    reg = get_registry()
    all_addons = []
    for m in reg.list_all():
        all_addons.append({**m, 'addon_type': 'voicebank_mapper'})
    # Also pull from addon_registry if it's been instantiated
    try:
        ar = AddonRegistry.__instances__  if hasattr(AddonRegistry,'__instances__') else None
    except Exception:
        ar = None
    return all_addons


def handle_reload_module(msg: dict):
    module_id = msg.get('module_id', '')
    if not module_id:
        raise ValueError('module_id is required')
    result = get_registry().reload(module_id)
    return {'status': result, 'module_id': module_id}


def handle_cache_stats(_msg: dict):
    return {
        'g2p':    get_g2p_cache().stats(),
        'phrase': get_phrase_cache().stats(),
    }


def handle_cache_clear(msg: dict):
    target = msg.get('target', 'all')  # 'g2p', 'phrase', 'all'
    lang   = msg.get('lang', None)
    if target in ('g2p', 'all'):
        get_g2p_cache().clear(lang)
    if target in ('phrase', 'all'):
        get_phrase_cache().clear()
    return {'cleared': target}


def handle_convert(msg: dict):
    text        = msg.get('text', '').strip()
    module_id   = msg.get('module_id', 'jp_cv_standard')
    singability = float(msg.get('singability', 0.5))
    lang        = msg.get('lang', None)
    use_cache   = bool(msg.get('cache', True))

    if not text:
        raise ValueError('text is required')
    if not (0.0 <= singability <= 1.0):
        raise ValueError('singability must be in [0.0, 1.0]')

    registry = get_registry()
    module   = registry.get(module_id)
    if module is None:
        available = [m['id'] for m in registry.list_all()]
        raise ValueError(f'Module "{module_id}" not found. Available: {available}')

    t_start = time.time()

    # Auto-detect language
    if not lang:
        try:
            from langdetect import detect
            lang = detect(text)
        except Exception:
            lang = 'en'

    # Check phrase cache
    if use_cache:
        cached = get_phrase_cache().get(
            text, lang, module_id, module.version, singability
        )
        if cached:
            cached['from_cache'] = True
            cached['processing_ms'] = int((time.time() - t_start) * 1000)
            return cached

    # G2P
    g2p = get_g2p()
    ipf_phonemes, words, normalised = g2p.process(text, lang)

    # Module mapping
    synth_tokens = module.map_phonemes(ipf_phonemes, singability)
    synth_tokens = module.postprocess(synth_tokens, singability)

    # Confidence scoring
    scorer = get_scorer()
    synth_tokens, warnings, overall_conf = scorer.score(
        synth_tokens,
        module.supported_phonemes,
        lang,
        module.phoneme_set,
    )

    # Build word boundaries
    word_boundaries: list[tuple[int, int]] = []
    for word_idx in range(len(words)):
        indices = [i for i, t in enumerate(synth_tokens) if t.word_index == word_idx]
        word_boundaries.append((indices[0], indices[-1]) if indices else (-1, -1))

    # Build phrase breaks (at punctuation gaps or long pauses in original)
    phrase_breaks: list[int] = []
    for i, w in enumerate(words):
        if i > 0 and i < len(words) - 1:
            if len(words[i-1]) > 4 and len(words[i]) > 4:  # simple heuristic
                pass  # real impl: use punctuation in original text

    from core.mlc_types import ConversionOutput
    output = ConversionOutput(
        tokens=synth_tokens,
        words=words,
        word_boundaries=word_boundaries,
        phrase_breaks=phrase_breaks,
        language=lang,
        module_id=module_id,
        singability=singability,
        confidence_score=overall_conf,
        warnings=warnings,
        processing_ms=int((time.time() - t_start) * 1000),
    )
    result = output.to_dict()
    result['from_cache'] = False

    # Store in phrase cache
    if use_cache:
        get_phrase_cache().put(text, lang, module_id, module.version, singability, result)

    return result


def handle_preview(msg: dict):
    """
    Quick preview: convert just the first 10 words.
    Used by the UI for live preview as the user types.
    """
    text = msg.get('text', '').strip()
    words = text.split()[:10]
    msg['text'] = ' '.join(words)
    msg['cache'] = True
    return handle_convert(msg)


def handle_suggest_singability(msg: dict):
    """
    Analyse the text and suggest a good starting singability value.
    Returns {'suggested': float, 'reason': str}
    """
    text = msg.get('text', '').strip()
    lang = msg.get('lang', 'en')
    module_id = msg.get('module_id', 'jp_cv_standard')

    # Heuristics:
    # - Many consonant clusters → lower singability (need accuracy)
    # - Short words, lots of vowels → higher singability (can simplify)
    # - JP target → 0.65 is usually right for pop

    words = text.lower().split()
    if not words:
        return {'suggested': 0.5, 'reason': 'Default'}

    avg_len = sum(len(w) for w in words) / len(words)
    vowel_ratio = sum(1 for c in text.lower() if c in 'aeiou') / max(len(text), 1)

    if module_id.startswith('jp'):
        if avg_len > 6 and vowel_ratio < 0.3:
            return {'suggested': 0.45, 'reason': 'Long words with few vowels — keeping more detail'}
        elif avg_len <= 4 or vowel_ratio > 0.45:
            return {'suggested': 0.75, 'reason': 'Short words / vowel-heavy — simplified will flow naturally'}
        else:
            return {'suggested': 0.65, 'reason': 'Standard J-pop setting'}
    else:
        return {'suggested': 0.5, 'reason': 'Balanced default'}



def handle_detect_system(_msg: dict):
    """Detect OpenUTAU, voicebanks, and music editors on this machine."""
    r = _get_render()
    ou_path     = r['find_openutau']()
    singers_dir = r['find_singers_dir']()
    voicebanks  = r['list_installed_voicebanks'](singers_dir) if singers_dir else []
    editors     = r['detect_music_editors']()
    return {
        'openutau': {
            'path':      str(ou_path) if ou_path else None,
            'found':     ou_path is not None,
        },
        'singers_dir': str(singers_dir) if singers_dir else None,
        'voicebanks': voicebanks,
        'editors':    editors,
    }


def handle_list_voicebanks(msg: dict):
    r = _get_render()
    custom_dir = msg.get('singers_dir')
    singers_dir = Path(custom_dir) if custom_dir else r['find_singers_dir']()
    return r['list_installed_voicebanks'](singers_dir)


def handle_detect_editors(_msg: dict):
    return _get_render()['detect_music_editors']()


def handle_generate_ust(msg: dict):
    """Generate a .ust file with full expression + flag support."""
    r = _get_render()
    notes        = msg.get('notes', [])
    bpm          = float(msg.get('tempo', 120.0))
    voice_dir    = msg.get('voice_dir')
    project_name = msg.get('project_name', 'melon_project')
    out_wav      = msg.get('out_wav')
    ust_path     = msg.get('save_path') or msg.get('ust_path')
    track_params = msg.get('track_params', {})
    pitch_points = msg.get('pitch_points', [])

    ust_text = r['generate_ust'](
        notes=notes, bpm=bpm, voice_dir=voice_dir,
        project_name=project_name, track_params=track_params,
        pitch_points=pitch_points, out_wav=out_wav,
    )

    saved_to = None
    if ust_path:
        Path(ust_path).parent.mkdir(parents=True, exist_ok=True)
        Path(ust_path).write_text(ust_text, encoding='utf-8-sig')
        saved_to = ust_path

    return {'ust': ust_text, 'saved_to': saved_to}


def handle_render(msg: dict):
    """Full render pipeline: notes → UST → OpenUTAU → WAV."""
    import tempfile, os
    r = _get_render()

    tmp_dir  = Path(tempfile.mkdtemp(prefix='melon_render_'))
    ust_path = tmp_dir / 'project.ust'
    wav_path = msg.get('out_wav', str(tmp_dir / 'render.wav'))

    # Generate UST with full expression support
    ust_text = r['generate_ust'](
        notes        = msg.get('notes', []),
        bpm          = float(msg.get('tempo', 120.0)),
        voice_dir    = msg.get('voice_dir') or msg.get('voicebank_path'),
        project_name = msg.get('project_name', 'melon_project'),
        track_params = msg.get('track_params', {}),
        pitch_points = msg.get('pitch_points', []),
        out_wav      = wav_path,
    )
    ust_path.write_text(ust_text, encoding='utf-8-sig')

    result = r['render'](
        ust_path       = str(ust_path),
        wav_out_path   = wav_path,
        voicebank_path = msg.get('voicebank_path') or msg.get('voice_dir'),
        openutau_path  = msg.get('openutau_path'),
        timeout_s      = int(msg.get('timeout_s', 300)),
    )
    res = result.to_dict()
    res['ust_path'] = str(ust_path)
    return res


def handle_open_editor(msg: dict):
    r = _get_render()
    return r['open_in_editor'](
        editor_id   = msg.get('editor_id', 'ardour'),
        wav_path    = msg.get('wav_path', ''),
        editor_path = msg.get('editor_path'),
    )


# ── Dispatch table ────────────────────────────────────────────────────────

HANDLERS = {
    'ping':               handle_ping,
    'list_modules':       handle_list_modules,
    'detect_lang':        handle_detect_lang,
    'convert':            handle_convert,
    'preview':            handle_preview,
    'install_module':     handle_install_module,
    'reload_module':      handle_reload_module,
    'cache_stats':        handle_cache_stats,
    'cache_clear':        handle_cache_clear,
    'suggest_singability':handle_suggest_singability,
    'list_all_addons':    handle_list_all_addons,
    'detect_system':      handle_detect_system,
    'list_voicebanks':    handle_list_voicebanks,
    'detect_editors':     handle_detect_editors,
    'generate_ust':       handle_generate_ust,
    'render':             handle_render,
    'open_editor':        handle_open_editor,
}


# ── IPC loop ──────────────────────────────────────────────────────────────

def respond(msg_id: str, data=None, error: str = None):
    payload = {'id': msg_id, 'ok': error is None, 'data': data, 'error': error}
    sys.stdout.write(json.dumps(payload) + '\n')
    sys.stdout.flush()


def main():
    log.info('MLC v2 starting')

    # Eagerly init on startup (so first request is fast)
    try:
        get_registry()
        get_g2p_cache()
        get_phrase_cache()
        log.info('MLC v2 ready')
    except Exception as e:
        log.warning(f'Startup init partial: {e}')

    for raw in sys.stdin:
        raw = raw.strip()
        if not raw:
            continue

        try:
            msg = json.loads(raw)
        except json.JSONDecodeError as e:
            sys.stdout.write(json.dumps({'id':None,'ok':False,'data':None,'error':f'invalid JSON: {e}'})+'\n')
            sys.stdout.flush()
            continue

        msg_id = msg.get('id', 'unknown')
        action = msg.get('action', '')

        try:
            handler = HANDLERS.get(action)
            if not handler:
                respond(msg_id, None, f'Unknown action: "{action}". Available: {list(HANDLERS)}')
                continue
            data = handler(msg)
            respond(msg_id, data)
        except Exception as e:
            tb = traceback.format_exc()
            log.error(f'Error handling {action} ({msg_id}):\n{tb}')
            respond(msg_id, None, str(e))


if __name__ == '__main__':
    main()
